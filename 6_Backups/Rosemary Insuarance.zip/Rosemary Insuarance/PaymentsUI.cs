﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Rosemary_Insuarance
{
    public partial class PaymentsUI: Form
    {
        private string userRole;
        private string currentUserId;

        public PaymentsUI(string role, string username)
        {
            InitializeComponent();
            userRole = role;
            currentUserId = GetUserNationalID(username);
            LoadPayments();
            ConfigureAccess();
        }
        private string GetUserNationalID(string username)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "SELECT NationalID FROM Policyholder WHERE Username = @username";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@username", username);
                    object result = cmd.ExecuteScalar();
                    return result?.ToString() ?? "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving user ID: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return "";
                }
                finally
                {
                    conn.Close();
                }
            }
        }
        private void ConfigureAccess()
        {
            switch (userRole.ToLower())
            {
                case "admin":
                    btnRecord.Enabled = true;
                    btnUpdate.Enabled = true;
                    btnSearch.Enabled = true;
                    btnClear.Enabled = true;
                    cmbStatus.Enabled = true;
                    txtPolicyID.Enabled = true;
                    break;
                case "agent":
                    btnRecord.Enabled = true;
                    btnUpdate.Enabled = true;
                    btnSearch.Enabled = true;
                    btnClear.Enabled = true;
                    cmbStatus.Enabled = true;
                    txtPolicyID.Enabled = true;
                    break;
                case "client":
                    btnRecord.Enabled = false;
                    btnUpdate.Enabled = false;
                    btnSearch.Enabled = true;
                    btnClear.Enabled = true;
                    cmbStatus.Enabled = false;
                    txtPolicyID.Enabled = false; // Clients can't change PolicyID
                    // PolicyID will be set via DataGridView or dropdown in future enhancements
                    break;
                default:
                    btnRecord.Enabled = false;
                    btnUpdate.Enabled = false;
                    btnSearch.Enabled = false;
                    btnClear.Enabled = false;
                    btnReturn.Enabled = true;
                    break;
            }
        }
        private void LoadPayments()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "SELECT PaymentID, PolicyID, Amount, PaymentDate, PaymentMethod, Status FROM Payment";
                if (userRole.ToLower() == "client")
                {
                    query += " WHERE PolicyID IN (SELECT PolicyID FROM Policy WHERE PolicyholderID = @policyholderId)";
                }
                MySqlCommand cmd = new MySqlCommand(query, conn);
                if (userRole.ToLower() == "client")
                {
                    cmd.Parameters.AddWithValue("@policyholderId", currentUserId);
                }
                try
                {
                    var adapter = new MySqlDataAdapter(cmd);
                    var dt = new DataTable();
                    adapter.Fill(dt);
                    dgvPayments.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading payments: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private bool ValidatePolicyID(string policyID)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "SELECT COUNT(*) FROM Policy WHERE PolicyID = @policyID";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@policyID", policyID);
                    long count = (long)cmd.ExecuteScalar();
                    return count > 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error validating Policy ID: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                finally
                {
                    conn.Close();
                }
            }
        }
        private string GeneratePaymentID()
        {
            return "PAY" + DateTime.Now.ToString("yyyyMMddHHmmss");
        }
        private void ClearFields()
        {
            txtPaymentID.Text = "";
            txtPolicyID.Text = "";
            numAmount.Value = 0;
            dtpPaymentDate.Value = DateTime.Now;
            cmbPaymentMethod.SelectedIndex = -1;
            cmbStatus.SelectedIndex = -1;
        }

        private void txtPaymentID_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRecord_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPolicyID.Text) ||
                numAmount.Value <= 0 ||
                cmbPaymentMethod.SelectedIndex == -1)
            {
                MessageBox.Show("Policy ID, Amount, and Payment Method are required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ValidatePolicyID(txtPolicyID.Text))
            {
                MessageBox.Show("Invalid Policy ID! Please enter a valid Policy ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string paymentID = GeneratePaymentID();

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "INSERT INTO Payment (PaymentID, PolicyID, Amount, PaymentDate, PaymentMethod, Status) " +
                              "VALUES (@PaymentID, @PolicyID, @Amount, @PaymentDate, @PaymentMethod, @Status)";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@PaymentID", paymentID);
                cmd.Parameters.AddWithValue("@PolicyID", txtPolicyID.Text);
                cmd.Parameters.AddWithValue("@Amount", numAmount.Value);
                cmd.Parameters.AddWithValue("@PaymentDate", dtpPaymentDate.Value);
                cmd.Parameters.AddWithValue("@PaymentMethod", cmbPaymentMethod.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Status", cmbStatus.SelectedItem?.ToString() ?? "Pending");

                try
                {
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    MessageBox.Show($"{rows} payment(s) recorded.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error recording payment: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn.Close();
                }

                LoadPayments();
                ClearFields();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPaymentID.Text))
            {
                MessageBox.Show("Select a payment to update!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ValidatePolicyID(txtPolicyID.Text))
            {
                MessageBox.Show("Invalid Policy ID! Please enter a valid Policy ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "UPDATE Payment SET PolicyID = @PolicyID, Amount = @Amount, PaymentDate = @PaymentDate, " +
                              "PaymentMethod = @PaymentMethod, Status = @Status WHERE PaymentID = @PaymentID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@PaymentID", txtPaymentID.Text);
                cmd.Parameters.AddWithValue("@PolicyID", txtPolicyID.Text);
                cmd.Parameters.AddWithValue("@Amount", numAmount.Value);
                cmd.Parameters.AddWithValue("@PaymentDate", dtpPaymentDate.Value);
                cmd.Parameters.AddWithValue("@PaymentMethod", cmbPaymentMethod.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Status", cmbStatus.SelectedItem.ToString());

                try
                {
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    MessageBox.Show($"{rows} payment(s) updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating payment: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn.Close();
                }

                LoadPayments();
                ClearFields();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "SELECT PaymentID, PolicyID, Amount, PaymentDate, PaymentMethod, Status " +
                              "FROM Payment WHERE PaymentID LIKE @search OR PolicyID LIKE @search";
                if (userRole.ToLower() == "client")
                {
                    query += " AND PolicyID IN (SELECT PolicyID FROM Policy WHERE PolicyholderID = @policyholderId)";
                }
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@search", "%" + txtPaymentID.Text + "%");
                if (userRole.ToLower() == "client")
                {
                    cmd.Parameters.AddWithValue("@policyholderId", currentUserId);
                }

                try
                {
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    var dt = new DataTable();
                    adapter.Fill(dt);
                    dgvPayments.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error searching payments: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
