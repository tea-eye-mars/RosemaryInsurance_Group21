﻿namespace Rosemary_Insuarance
{
    partial class PoliciesUI
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblPolicyID = new System.Windows.Forms.Label();
            this.lblPolicyholderID = new System.Windows.Forms.Label();
            this.lblPolicyType = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblPremium = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtPolicyID = new System.Windows.Forms.TextBox();
            this.txtPolicyholderID = new System.Windows.Forms.TextBox();
            this.cmbPolicyType = new System.Windows.Forms.ComboBox();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.numPremium = new System.Windows.Forms.NumericUpDown();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.dgvPolicies = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.numPremium)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPolicies)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(250, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(300, 40);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Policies Management";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPolicyID
            // 
            this.lblPolicyID.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblPolicyID.Location = new System.Drawing.Point(50, 70);
            this.lblPolicyID.Name = "lblPolicyID";
            this.lblPolicyID.Size = new System.Drawing.Size(100, 30);
            this.lblPolicyID.TabIndex = 1;
            this.lblPolicyID.Text = "Policy ID:";
            // 
            // lblPolicyholderID
            // 
            this.lblPolicyholderID.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblPolicyholderID.Location = new System.Drawing.Point(50, 110);
            this.lblPolicyholderID.Name = "lblPolicyholderID";
            this.lblPolicyholderID.Size = new System.Drawing.Size(120, 30);
            this.lblPolicyholderID.TabIndex = 2;
            this.lblPolicyholderID.Text = "Policyholder ID:";
            // 
            // lblPolicyType
            // 
            this.lblPolicyType.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblPolicyType.Location = new System.Drawing.Point(50, 150);
            this.lblPolicyType.Name = "lblPolicyType";
            this.lblPolicyType.Size = new System.Drawing.Size(100, 30);
            this.lblPolicyType.TabIndex = 3;
            this.lblPolicyType.Text = "Policy Type:";
            // 
            // lblStartDate
            // 
            this.lblStartDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblStartDate.Location = new System.Drawing.Point(50, 190);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(100, 30);
            this.lblStartDate.TabIndex = 4;
            this.lblStartDate.Text = "Start Date:";
            // 
            // lblEndDate
            // 
            this.lblEndDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblEndDate.Location = new System.Drawing.Point(50, 230);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(100, 30);
            this.lblEndDate.TabIndex = 5;
            this.lblEndDate.Text = "End Date:";
            // 
            // lblPremium
            // 
            this.lblPremium.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblPremium.Location = new System.Drawing.Point(50, 270);
            this.lblPremium.Name = "lblPremium";
            this.lblPremium.Size = new System.Drawing.Size(100, 30);
            this.lblPremium.TabIndex = 6;
            this.lblPremium.Text = "Premium:";
            // 
            // lblStatus
            // 
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblStatus.Location = new System.Drawing.Point(50, 310);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(100, 30);
            this.lblStatus.TabIndex = 7;
            this.lblStatus.Text = "Status:";
            // 
            // txtPolicyID
            // 
            this.txtPolicyID.Enabled = false;
            this.txtPolicyID.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtPolicyID.Location = new System.Drawing.Point(180, 70);
            this.txtPolicyID.Name = "txtPolicyID";
            this.txtPolicyID.Size = new System.Drawing.Size(297, 34);
            this.txtPolicyID.TabIndex = 8;
            // 
            // txtPolicyholderID
            // 
            this.txtPolicyholderID.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtPolicyholderID.Location = new System.Drawing.Point(180, 110);
            this.txtPolicyholderID.Name = "txtPolicyholderID";
            this.txtPolicyholderID.Size = new System.Drawing.Size(297, 34);
            this.txtPolicyholderID.TabIndex = 9;
            // 
            // cmbPolicyType
            // 
            this.cmbPolicyType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPolicyType.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cmbPolicyType.Items.AddRange(new object[] {
            "Auto",
            "Home",
            "Health",
            "Life",
            "Other"});
            this.cmbPolicyType.Location = new System.Drawing.Point(180, 150);
            this.cmbPolicyType.Name = "cmbPolicyType";
            this.cmbPolicyType.Size = new System.Drawing.Size(297, 36);
            this.cmbPolicyType.TabIndex = 10;
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dtpStartDate.Location = new System.Drawing.Point(180, 190);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(297, 34);
            this.dtpStartDate.TabIndex = 11;
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dtpEndDate.Location = new System.Drawing.Point(180, 230);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(297, 34);
            this.dtpEndDate.TabIndex = 12;
            // 
            // numPremium
            // 
            this.numPremium.DecimalPlaces = 2;
            this.numPremium.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.numPremium.Location = new System.Drawing.Point(180, 270);
            this.numPremium.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numPremium.Name = "numPremium";
            this.numPremium.Size = new System.Drawing.Size(297, 34);
            this.numPremium.TabIndex = 13;
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cmbStatus.Items.AddRange(new object[] {
            "Active",
            "Expired",
            "Cancelled",
            "Pending"});
            this.cmbStatus.Location = new System.Drawing.Point(180, 310);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(297, 36);
            this.cmbStatus.TabIndex = 14;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Location = new System.Drawing.Point(78, 381);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(120, 40);
            this.btnAdd.TabIndex = 15;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnUpdate.Location = new System.Drawing.Point(208, 381);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(120, 40);
            this.btnUpdate.TabIndex = 16;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnCancel.Location = new System.Drawing.Point(338, 381);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(120, 40);
            this.btnCancel.TabIndex = 17;
            this.btnCancel.Text = "Cancel Policy";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnSearch.Location = new System.Drawing.Point(78, 431);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(120, 40);
            this.btnSearch.TabIndex = 18;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnClear.Location = new System.Drawing.Point(208, 431);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(120, 40);
            this.btnClear.TabIndex = 19;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnReturn.Location = new System.Drawing.Point(338, 431);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(120, 40);
            this.btnReturn.TabIndex = 20;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // dgvPolicies
            // 
            this.dgvPolicies.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPolicies.Location = new System.Drawing.Point(538, 70);
            this.dgvPolicies.Name = "dgvPolicies";
            this.dgvPolicies.RowHeadersWidth = 51;
            this.dgvPolicies.RowTemplate.Height = 24;
            this.dgvPolicies.Size = new System.Drawing.Size(751, 380);
            this.dgvPolicies.TabIndex = 21;
            this.dgvPolicies.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPolicies_CellContentClick);
            // 
            // PoliciesUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1340, 540);
            this.Controls.Add(this.dgvPolicies);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.numPremium);
            this.Controls.Add(this.dtpEndDate);
            this.Controls.Add(this.dtpStartDate);
            this.Controls.Add(this.cmbPolicyType);
            this.Controls.Add(this.txtPolicyholderID);
            this.Controls.Add(this.txtPolicyID);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblPremium);
            this.Controls.Add(this.lblEndDate);
            this.Controls.Add(this.lblStartDate);
            this.Controls.Add(this.lblPolicyType);
            this.Controls.Add(this.lblPolicyholderID);
            this.Controls.Add(this.lblPolicyID);
            this.Controls.Add(this.lblTitle);
            this.Name = "PoliciesUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Policies - Rosemary Insurance";
            ((System.ComponentModel.ISupportInitialize)(this.numPremium)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPolicies)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblPolicyID;
        private System.Windows.Forms.Label lblPolicyholderID;
        private System.Windows.Forms.Label lblPolicyType;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblPremium;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TextBox txtPolicyID;
        private System.Windows.Forms.TextBox txtPolicyholderID;
        private System.Windows.Forms.ComboBox cmbPolicyType;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.NumericUpDown numPremium;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.DataGridView dgvPolicies;
    }
}