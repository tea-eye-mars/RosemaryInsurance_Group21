﻿namespace Rosemary_Insuarance
{
    partial class ClaimsUI
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblPolicyID = new System.Windows.Forms.Label();
            this.lblClaimType = new System.Windows.Forms.Label();
            this.lblIncidentDate = new System.Windows.Forms.Label();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblDocuments = new System.Windows.Forms.Label();
            this.txtPolicyID = new System.Windows.Forms.TextBox();
            this.cmbClaimType = new System.Windows.Forms.ComboBox();
            this.dtpIncidentDate = new System.Windows.Forms.DateTimePicker();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.numAmount = new System.Windows.Forms.NumericUpDown();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.btnUploadDocuments = new System.Windows.Forms.Button();
            this.btnFileClaim = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.dgvClaims = new System.Windows.Forms.DataGridView();
            this.lblClaimID = new System.Windows.Forms.Label();
            this.txtClaimID = new System.Windows.Forms.TextBox();
            this.ofdDocuments = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.numAmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClaims)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(485, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(300, 40);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Claims Management";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPolicyID
            // 
            this.lblPolicyID.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblPolicyID.Location = new System.Drawing.Point(59, 111);
            this.lblPolicyID.Name = "lblPolicyID";
            this.lblPolicyID.Size = new System.Drawing.Size(137, 30);
            this.lblPolicyID.TabIndex = 3;
            this.lblPolicyID.Text = "Policy ID:";
            // 
            // lblClaimType
            // 
            this.lblClaimType.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblClaimType.Location = new System.Drawing.Point(59, 151);
            this.lblClaimType.Name = "lblClaimType";
            this.lblClaimType.Size = new System.Drawing.Size(137, 30);
            this.lblClaimType.TabIndex = 5;
            this.lblClaimType.Text = "Claim Type:";
            // 
            // lblIncidentDate
            // 
            this.lblIncidentDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblIncidentDate.Location = new System.Drawing.Point(59, 191);
            this.lblIncidentDate.Name = "lblIncidentDate";
            this.lblIncidentDate.Size = new System.Drawing.Size(157, 30);
            this.lblIncidentDate.TabIndex = 7;
            this.lblIncidentDate.Text = "Incident Date:";
            // 
            // lblDescription
            // 
            this.lblDescription.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblDescription.Location = new System.Drawing.Point(59, 231);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(137, 30);
            this.lblDescription.TabIndex = 9;
            this.lblDescription.Text = "Description:";
            // 
            // lblAmount
            // 
            this.lblAmount.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblAmount.Location = new System.Drawing.Point(59, 311);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(137, 30);
            this.lblAmount.TabIndex = 11;
            this.lblAmount.Text = "Amount:";
            // 
            // lblStatus
            // 
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblStatus.Location = new System.Drawing.Point(59, 351);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(137, 30);
            this.lblStatus.TabIndex = 13;
            this.lblStatus.Text = "Status:";
            // 
            // lblDocuments
            // 
            this.lblDocuments.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblDocuments.Location = new System.Drawing.Point(59, 391);
            this.lblDocuments.Name = "lblDocuments";
            this.lblDocuments.Size = new System.Drawing.Size(157, 30);
            this.lblDocuments.TabIndex = 15;
            this.lblDocuments.Text = "Documents:";
            // 
            // txtPolicyID
            // 
            this.txtPolicyID.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtPolicyID.Location = new System.Drawing.Point(240, 108);
            this.txtPolicyID.Name = "txtPolicyID";
            this.txtPolicyID.Size = new System.Drawing.Size(332, 34);
            this.txtPolicyID.TabIndex = 4;
            // 
            // cmbClaimType
            // 
            this.cmbClaimType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbClaimType.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cmbClaimType.Items.AddRange(new object[] {
            "Accident",
            "Theft",
            "Medical",
            "Property Damage",
            "Other"});
            this.cmbClaimType.Location = new System.Drawing.Point(240, 148);
            this.cmbClaimType.Name = "cmbClaimType";
            this.cmbClaimType.Size = new System.Drawing.Size(332, 36);
            this.cmbClaimType.TabIndex = 6;
            // 
            // dtpIncidentDate
            // 
            this.dtpIncidentDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dtpIncidentDate.Location = new System.Drawing.Point(240, 188);
            this.dtpIncidentDate.Name = "dtpIncidentDate";
            this.dtpIncidentDate.Size = new System.Drawing.Size(332, 34);
            this.dtpIncidentDate.TabIndex = 8;
            // 
            // txtDescription
            // 
            this.txtDescription.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtDescription.Location = new System.Drawing.Point(240, 228);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(332, 70);
            this.txtDescription.TabIndex = 10;
            // 
            // numAmount
            // 
            this.numAmount.DecimalPlaces = 2;
            this.numAmount.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.numAmount.Location = new System.Drawing.Point(240, 308);
            this.numAmount.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numAmount.Name = "numAmount";
            this.numAmount.Size = new System.Drawing.Size(332, 34);
            this.numAmount.TabIndex = 12;
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cmbStatus.Items.AddRange(new object[] {
            "Pending",
            "Approved",
            "Rejected",
            "In Review"});
            this.cmbStatus.Location = new System.Drawing.Point(240, 348);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(332, 36);
            this.cmbStatus.TabIndex = 14;
            // 
            // btnUploadDocuments
            // 
            this.btnUploadDocuments.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnUploadDocuments.Location = new System.Drawing.Point(240, 388);
            this.btnUploadDocuments.Name = "btnUploadDocuments";
            this.btnUploadDocuments.Size = new System.Drawing.Size(332, 40);
            this.btnUploadDocuments.TabIndex = 16;
            this.btnUploadDocuments.Text = "Upload Documents";
            this.btnUploadDocuments.UseVisualStyleBackColor = true;
            // 
            // btnFileClaim
            // 
            this.btnFileClaim.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnFileClaim.Location = new System.Drawing.Point(111, 466);
            this.btnFileClaim.Name = "btnFileClaim";
            this.btnFileClaim.Size = new System.Drawing.Size(120, 40);
            this.btnFileClaim.TabIndex = 17;
            this.btnFileClaim.Text = "File Claim";
            this.btnFileClaim.UseVisualStyleBackColor = true;
            this.btnFileClaim.Click += new System.EventHandler(this.btnFileClaim_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnUpdate.Location = new System.Drawing.Point(241, 466);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(120, 40);
            this.btnUpdate.TabIndex = 18;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnDelete.Location = new System.Drawing.Point(371, 466);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(120, 40);
            this.btnDelete.TabIndex = 19;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnSearch.Location = new System.Drawing.Point(111, 516);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(120, 40);
            this.btnSearch.TabIndex = 20;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnClear.Location = new System.Drawing.Point(241, 516);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(120, 40);
            this.btnClear.TabIndex = 21;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnReturn.Location = new System.Drawing.Point(371, 516);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(120, 40);
            this.btnReturn.TabIndex = 22;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // dgvClaims
            // 
            this.dgvClaims.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvClaims.Location = new System.Drawing.Point(593, 68);
            this.dgvClaims.Name = "dgvClaims";
            this.dgvClaims.RowHeadersWidth = 51;
            this.dgvClaims.RowTemplate.Height = 24;
            this.dgvClaims.Size = new System.Drawing.Size(659, 488);
            this.dgvClaims.TabIndex = 23;
            // 
            // lblClaimID
            // 
            this.lblClaimID.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblClaimID.Location = new System.Drawing.Point(59, 71);
            this.lblClaimID.Name = "lblClaimID";
            this.lblClaimID.Size = new System.Drawing.Size(137, 30);
            this.lblClaimID.TabIndex = 1;
            this.lblClaimID.Text = "Claim ID:";
            // 
            // txtClaimID
            // 
            this.txtClaimID.Enabled = false;
            this.txtClaimID.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtClaimID.Location = new System.Drawing.Point(240, 68);
            this.txtClaimID.Name = "txtClaimID";
            this.txtClaimID.Size = new System.Drawing.Size(332, 34);
            this.txtClaimID.TabIndex = 2;
            // 
            // ofdDocuments
            // 
            this.ofdDocuments.FileName = "openFileDialog1";
            // 
            // ClaimsUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1328, 611);
            this.Controls.Add(this.txtClaimID);
            this.Controls.Add(this.lblClaimID);
            this.Controls.Add(this.dgvClaims);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnFileClaim);
            this.Controls.Add(this.btnUploadDocuments);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.numAmount);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.dtpIncidentDate);
            this.Controls.Add(this.cmbClaimType);
            this.Controls.Add(this.txtPolicyID);
            this.Controls.Add(this.lblDocuments);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblAmount);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblIncidentDate);
            this.Controls.Add(this.lblClaimType);
            this.Controls.Add(this.lblPolicyID);
            this.Controls.Add(this.lblTitle);
            this.Name = "ClaimsUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Claims - Rosemary Insurance";
            ((System.ComponentModel.ISupportInitialize)(this.numAmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClaims)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblPolicyID;
        private System.Windows.Forms.Label lblClaimType;
        private System.Windows.Forms.Label lblIncidentDate;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblDocuments;
        private System.Windows.Forms.TextBox txtPolicyID;
        private System.Windows.Forms.ComboBox cmbClaimType;
        private System.Windows.Forms.DateTimePicker dtpIncidentDate;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.NumericUpDown numAmount;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Button btnUploadDocuments;
        private System.Windows.Forms.Button btnFileClaim;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.DataGridView dgvClaims;
        private System.Windows.Forms.Label lblClaimID;
        private System.Windows.Forms.TextBox txtClaimID;
        private System.Windows.Forms.OpenFileDialog ofdDocuments;
    }
}