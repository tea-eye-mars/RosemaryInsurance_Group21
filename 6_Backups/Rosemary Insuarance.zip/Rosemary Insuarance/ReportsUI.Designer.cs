﻿namespace Rosemary_Insuarance
{
    partial class ReportsUI
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.tabControlReports = new System.Windows.Forms.TabControl();
            this.tabPolicies = new System.Windows.Forms.TabPage();
            this.dgvPoliciesReport = new System.Windows.Forms.DataGridView();
            this.btnExportPolicies = new System.Windows.Forms.Button();
            this.btnGeneratePolicies = new System.Windows.Forms.Button();
            this.dtpPoliciesEndDate = new System.Windows.Forms.DateTimePicker();
            this.dtpPoliciesStartDate = new System.Windows.Forms.DateTimePicker();
            this.lblPoliciesDateRange = new System.Windows.Forms.Label();
            this.tabClaims = new System.Windows.Forms.TabPage();
            this.dgvClaimsReport = new System.Windows.Forms.DataGridView();
            this.btnExportClaims = new System.Windows.Forms.Button();
            this.btnGenerateClaims = new System.Windows.Forms.Button();
            this.dtpClaimsEndDate = new System.Windows.Forms.DateTimePicker();
            this.dtpClaimsStartDate = new System.Windows.Forms.DateTimePicker();
            this.lblClaimsDateRange = new System.Windows.Forms.Label();
            this.tabPayments = new System.Windows.Forms.TabPage();
            this.dgvPaymentsReport = new System.Windows.Forms.DataGridView();
            this.btnExportPayments = new System.Windows.Forms.Button();
            this.btnGeneratePayments = new System.Windows.Forms.Button();
            this.dtpPaymentsEndDate = new System.Windows.Forms.DateTimePicker();
            this.dtpPaymentsStartDate = new System.Windows.Forms.DateTimePicker();
            this.lblPaymentsDateRange = new System.Windows.Forms.Label();
            this.lblPolicyholderID = new System.Windows.Forms.Label();
            this.txtPolicyholderID = new System.Windows.Forms.TextBox();
            this.btnReturn = new System.Windows.Forms.Button();
            this.tabControlReports.SuspendLayout();
            this.tabPolicies.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPoliciesReport)).BeginInit();
            this.tabClaims.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClaimsReport)).BeginInit();
            this.tabPayments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPaymentsReport)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(300, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(400, 40);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Reports - Rosemary Insurance";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControlReports
            // 
            this.tabControlReports.Controls.Add(this.tabPolicies);
            this.tabControlReports.Controls.Add(this.tabClaims);
            this.tabControlReports.Controls.Add(this.tabPayments);
            this.tabControlReports.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tabControlReports.Location = new System.Drawing.Point(50, 70);
            this.tabControlReports.Name = "tabControlReports";
            this.tabControlReports.SelectedIndex = 0;
            this.tabControlReports.Size = new System.Drawing.Size(900, 400);
            this.tabControlReports.TabIndex = 1;
            // 
            // tabPolicies
            // 
            this.tabPolicies.Controls.Add(this.dgvPoliciesReport);
            this.tabPolicies.Controls.Add(this.btnExportPolicies);
            this.tabPolicies.Controls.Add(this.btnGeneratePolicies);
            this.tabPolicies.Controls.Add(this.dtpPoliciesEndDate);
            this.tabPolicies.Controls.Add(this.dtpPoliciesStartDate);
            this.tabPolicies.Controls.Add(this.lblPoliciesDateRange);
            this.tabPolicies.Location = new System.Drawing.Point(4, 37);
            this.tabPolicies.Name = "tabPolicies";
            this.tabPolicies.Padding = new System.Windows.Forms.Padding(3);
            this.tabPolicies.Size = new System.Drawing.Size(892, 359);
            this.tabPolicies.TabIndex = 0;
            this.tabPolicies.Text = "Policies Report";
            this.tabPolicies.UseVisualStyleBackColor = true;
            // 
            // dgvPoliciesReport
            // 
            this.dgvPoliciesReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPoliciesReport.Location = new System.Drawing.Point(10, 80);
            this.dgvPoliciesReport.Name = "dgvPoliciesReport";
            this.dgvPoliciesReport.RowHeadersWidth = 51;
            this.dgvPoliciesReport.RowTemplate.Height = 24;
            this.dgvPoliciesReport.Size = new System.Drawing.Size(872, 250);
            this.dgvPoliciesReport.TabIndex = 0;
            // 
            // btnExportPolicies
            // 
            this.btnExportPolicies.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnExportPolicies.Location = new System.Drawing.Point(720, 20);
            this.btnExportPolicies.Name = "btnExportPolicies";
            this.btnExportPolicies.Size = new System.Drawing.Size(150, 40);
            this.btnExportPolicies.TabIndex = 5;
            this.btnExportPolicies.Text = "Export to CSV";
            this.btnExportPolicies.UseVisualStyleBackColor = true;
            this.btnExportPolicies.Click += new System.EventHandler(this.btnExportPolicies_Click);
            // 
            // btnGeneratePolicies
            // 
            this.btnGeneratePolicies.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnGeneratePolicies.Location = new System.Drawing.Point(560, 20);
            this.btnGeneratePolicies.Name = "btnGeneratePolicies";
            this.btnGeneratePolicies.Size = new System.Drawing.Size(150, 40);
            this.btnGeneratePolicies.TabIndex = 4;
            this.btnGeneratePolicies.Text = "Generate Report";
            this.btnGeneratePolicies.UseVisualStyleBackColor = true;
            this.btnGeneratePolicies.Click += new System.EventHandler(this.btnGeneratePolicies_Click);
            // 
            // dtpPoliciesEndDate
            // 
            this.dtpPoliciesEndDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dtpPoliciesEndDate.Location = new System.Drawing.Point(350, 20);
            this.dtpPoliciesEndDate.Name = "dtpPoliciesEndDate";
            this.dtpPoliciesEndDate.Size = new System.Drawing.Size(200, 34);
            this.dtpPoliciesEndDate.TabIndex = 3;
            // 
            // dtpPoliciesStartDate
            // 
            this.dtpPoliciesStartDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dtpPoliciesStartDate.Location = new System.Drawing.Point(140, 20);
            this.dtpPoliciesStartDate.Name = "dtpPoliciesStartDate";
            this.dtpPoliciesStartDate.Size = new System.Drawing.Size(200, 34);
            this.dtpPoliciesStartDate.TabIndex = 2;
            // 
            // lblPoliciesDateRange
            // 
            this.lblPoliciesDateRange.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblPoliciesDateRange.Location = new System.Drawing.Point(10, 20);
            this.lblPoliciesDateRange.Name = "lblPoliciesDateRange";
            this.lblPoliciesDateRange.Size = new System.Drawing.Size(120, 30);
            this.lblPoliciesDateRange.TabIndex = 1;
            this.lblPoliciesDateRange.Text = "Date Range:";
            // 
            // tabClaims
            // 
            this.tabClaims.Controls.Add(this.dgvClaimsReport);
            this.tabClaims.Controls.Add(this.btnExportClaims);
            this.tabClaims.Controls.Add(this.btnGenerateClaims);
            this.tabClaims.Controls.Add(this.dtpClaimsEndDate);
            this.tabClaims.Controls.Add(this.dtpClaimsStartDate);
            this.tabClaims.Controls.Add(this.lblClaimsDateRange);
            this.tabClaims.Location = new System.Drawing.Point(4, 37);
            this.tabClaims.Name = "tabClaims";
            this.tabClaims.Padding = new System.Windows.Forms.Padding(3);
            this.tabClaims.Size = new System.Drawing.Size(892, 359);
            this.tabClaims.TabIndex = 1;
            this.tabClaims.Text = "Claims Report";
            this.tabClaims.UseVisualStyleBackColor = true;
            // 
            // dgvClaimsReport
            // 
            this.dgvClaimsReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvClaimsReport.Location = new System.Drawing.Point(10, 80);
            this.dgvClaimsReport.Name = "dgvClaimsReport";
            this.dgvClaimsReport.RowHeadersWidth = 51;
            this.dgvClaimsReport.RowTemplate.Height = 24;
            this.dgvClaimsReport.Size = new System.Drawing.Size(872, 250);
            this.dgvClaimsReport.TabIndex = 0;
            // 
            // btnExportClaims
            // 
            this.btnExportClaims.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnExportClaims.Location = new System.Drawing.Point(720, 20);
            this.btnExportClaims.Name = "btnExportClaims";
            this.btnExportClaims.Size = new System.Drawing.Size(150, 40);
            this.btnExportClaims.TabIndex = 5;
            this.btnExportClaims.Text = "Export to CSV";
            this.btnExportClaims.UseVisualStyleBackColor = true;
            this.btnExportClaims.Click += new System.EventHandler(this.btnExportClaims_Click);
            // 
            // btnGenerateClaims
            // 
            this.btnGenerateClaims.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnGenerateClaims.Location = new System.Drawing.Point(560, 20);
            this.btnGenerateClaims.Name = "btnGenerateClaims";
            this.btnGenerateClaims.Size = new System.Drawing.Size(150, 40);
            this.btnGenerateClaims.TabIndex = 4;
            this.btnGenerateClaims.Text = "Generate Report";
            this.btnGenerateClaims.UseVisualStyleBackColor = true;
            this.btnGenerateClaims.Click += new System.EventHandler(this.btnGenerateClaims_Click);
            // 
            // dtpClaimsEndDate
            // 
            this.dtpClaimsEndDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dtpClaimsEndDate.Location = new System.Drawing.Point(350, 20);
            this.dtpClaimsEndDate.Name = "dtpClaimsEndDate";
            this.dtpClaimsEndDate.Size = new System.Drawing.Size(200, 34);
            this.dtpClaimsEndDate.TabIndex = 3;
            // 
            // dtpClaimsStartDate
            // 
            this.dtpClaimsStartDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dtpClaimsStartDate.Location = new System.Drawing.Point(140, 20);
            this.dtpClaimsStartDate.Name = "dtpClaimsStartDate";
            this.dtpClaimsStartDate.Size = new System.Drawing.Size(200, 34);
            this.dtpClaimsStartDate.TabIndex = 2;
            // 
            // lblClaimsDateRange
            // 
            this.lblClaimsDateRange.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblClaimsDateRange.Location = new System.Drawing.Point(10, 20);
            this.lblClaimsDateRange.Name = "lblClaimsDateRange";
            this.lblClaimsDateRange.Size = new System.Drawing.Size(120, 30);
            this.lblClaimsDateRange.TabIndex = 1;
            this.lblClaimsDateRange.Text = "Date Range:";
            // 
            // tabPayments
            // 
            this.tabPayments.Controls.Add(this.dgvPaymentsReport);
            this.tabPayments.Controls.Add(this.btnExportPayments);
            this.tabPayments.Controls.Add(this.btnGeneratePayments);
            this.tabPayments.Controls.Add(this.dtpPaymentsEndDate);
            this.tabPayments.Controls.Add(this.dtpPaymentsStartDate);
            this.tabPayments.Controls.Add(this.lblPaymentsDateRange);
            this.tabPayments.Location = new System.Drawing.Point(4, 37);
            this.tabPayments.Name = "tabPayments";
            this.tabPayments.Size = new System.Drawing.Size(892, 359);
            this.tabPayments.TabIndex = 2;
            this.tabPayments.Text = "Payments Report";
            this.tabPayments.UseVisualStyleBackColor = true;
            // 
            // dgvPaymentsReport
            // 
            this.dgvPaymentsReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPaymentsReport.Location = new System.Drawing.Point(10, 80);
            this.dgvPaymentsReport.Name = "dgvPaymentsReport";
            this.dgvPaymentsReport.RowHeadersWidth = 51;
            this.dgvPaymentsReport.RowTemplate.Height = 24;
            this.dgvPaymentsReport.Size = new System.Drawing.Size(872, 250);
            this.dgvPaymentsReport.TabIndex = 0;
            // 
            // btnExportPayments
            // 
            this.btnExportPayments.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnExportPayments.Location = new System.Drawing.Point(720, 20);
            this.btnExportPayments.Name = "btnExportPayments";
            this.btnExportPayments.Size = new System.Drawing.Size(150, 40);
            this.btnExportPayments.TabIndex = 5;
            this.btnExportPayments.Text = "Export to CSV";
            this.btnExportPayments.UseVisualStyleBackColor = true;
            this.btnExportPayments.Click += new System.EventHandler(this.btnExportPayments_Click);
            // 
            // btnGeneratePayments
            // 
            this.btnGeneratePayments.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnGeneratePayments.Location = new System.Drawing.Point(560, 20);
            this.btnGeneratePayments.Name = "btnGeneratePayments";
            this.btnGeneratePayments.Size = new System.Drawing.Size(150, 40);
            this.btnGeneratePayments.TabIndex = 4;
            this.btnGeneratePayments.Text = "Generate Report";
            this.btnGeneratePayments.UseVisualStyleBackColor = true;
            this.btnGeneratePayments.Click += new System.EventHandler(this.btnGeneratePayments_Click);
            // 
            // dtpPaymentsEndDate
            // 
            this.dtpPaymentsEndDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dtpPaymentsEndDate.Location = new System.Drawing.Point(350, 20);
            this.dtpPaymentsEndDate.Name = "dtpPaymentsEndDate";
            this.dtpPaymentsEndDate.Size = new System.Drawing.Size(200, 34);
            this.dtpPaymentsEndDate.TabIndex = 3;
            // 
            // dtpPaymentsStartDate
            // 
            this.dtpPaymentsStartDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dtpPaymentsStartDate.Location = new System.Drawing.Point(140, 20);
            this.dtpPaymentsStartDate.Name = "dtpPaymentsStartDate";
            this.dtpPaymentsStartDate.Size = new System.Drawing.Size(200, 34);
            this.dtpPaymentsStartDate.TabIndex = 2;
            // 
            // lblPaymentsDateRange
            // 
            this.lblPaymentsDateRange.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblPaymentsDateRange.Location = new System.Drawing.Point(10, 20);
            this.lblPaymentsDateRange.Name = "lblPaymentsDateRange";
            this.lblPaymentsDateRange.Size = new System.Drawing.Size(120, 30);
            this.lblPaymentsDateRange.TabIndex = 1;
            this.lblPaymentsDateRange.Text = "Date Range:";
            // 
            // lblPolicyholderID
            // 
            this.lblPolicyholderID.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblPolicyholderID.Location = new System.Drawing.Point(50, 480);
            this.lblPolicyholderID.Name = "lblPolicyholderID";
            this.lblPolicyholderID.Size = new System.Drawing.Size(120, 30);
            this.lblPolicyholderID.TabIndex = 2;
            this.lblPolicyholderID.Text = "Policyholder ID:";
            // 
            // txtPolicyholderID
            // 
            this.txtPolicyholderID.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtPolicyholderID.Location = new System.Drawing.Point(180, 480);
            this.txtPolicyholderID.Name = "txtPolicyholderID";
            this.txtPolicyholderID.Size = new System.Drawing.Size(200, 34);
            this.txtPolicyholderID.TabIndex = 3;
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnReturn.Location = new System.Drawing.Point(830, 480);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(120, 40);
            this.btnReturn.TabIndex = 4;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // ReportsUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 540);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.txtPolicyholderID);
            this.Controls.Add(this.lblPolicyholderID);
            this.Controls.Add(this.tabControlReports);
            this.Controls.Add(this.lblTitle);
            this.Name = "ReportsUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reports - Rosemary Insurance";
            this.tabControlReports.ResumeLayout(false);
            this.tabPolicies.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPoliciesReport)).EndInit();
            this.tabClaims.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvClaimsReport)).EndInit();
            this.tabPayments.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPaymentsReport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TabControl tabControlReports;
        private System.Windows.Forms.TabPage tabPolicies;
        private System.Windows.Forms.TabPage tabClaims;
        private System.Windows.Forms.TabPage tabPayments;
        private System.Windows.Forms.DataGridView dgvPoliciesReport;
        private System.Windows.Forms.DataGridView dgvClaimsReport;
        private System.Windows.Forms.DataGridView dgvPaymentsReport;
        private System.Windows.Forms.Label lblPoliciesDateRange;
        private System.Windows.Forms.Label lblClaimsDateRange;
        private System.Windows.Forms.Label lblPaymentsDateRange;
        private System.Windows.Forms.DateTimePicker dtpPoliciesStartDate;
        private System.Windows.Forms.DateTimePicker dtpPoliciesEndDate;
        private System.Windows.Forms.DateTimePicker dtpClaimsStartDate;
        private System.Windows.Forms.DateTimePicker dtpClaimsEndDate;
        private System.Windows.Forms.DateTimePicker dtpPaymentsStartDate;
        private System.Windows.Forms.DateTimePicker dtpPaymentsEndDate;
        private System.Windows.Forms.Label lblPolicyholderID;
        private System.Windows.Forms.TextBox txtPolicyholderID;
        private System.Windows.Forms.Button btnGeneratePolicies;
        private System.Windows.Forms.Button btnGenerateClaims;
        private System.Windows.Forms.Button btnGeneratePayments;
        private System.Windows.Forms.Button btnExportPolicies;
        private System.Windows.Forms.Button btnExportClaims;
        private System.Windows.Forms.Button btnExportPayments;
        private System.Windows.Forms.Button btnReturn;
    }
}