﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Rosemary_Insuarance
{
    public partial class ReportsUI: Form
    {
        private string userRole;
        private string currentUserId;

        public ReportsUI(string role, string username)
        {
            InitializeComponent();
            userRole = role;
            currentUserId = GetUserNationalID(username); // Get NationalID for client filtering
            ConfigureAccess();
            LoadDefaultReports();
        }
        private string GetUserNationalID(string username)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "SELECT NationalID FROM Policyholder WHERE Username = @username";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@username", username);
                    object result = cmd.ExecuteScalar();
                    return result?.ToString() ?? "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving user ID: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return "";
                }
                finally
                {
                    conn.Close();
                }
            }
        }
        private void LoadDefaultReports()
        {
            DateTime defaultStart = DateTime.Now.AddYears(-1);
            dtpPoliciesStartDate.Value = defaultStart;
            dtpClaimsStartDate.Value = defaultStart;
            dtpPaymentsStartDate.Value = defaultStart;
            GeneratePoliciesReport();
            GenerateClaimsReport();
            GeneratePaymentsReport();
        }
        private bool ValidateDateRange(DateTime startDate, DateTime endDate)
        {
            if (startDate > endDate)
            {
                MessageBox.Show("Start Date must be before or equal to End Date!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void ConfigureAccess()
        {
            switch (userRole.ToLower())
            {
                case "admin":
                    tabControlReports.Enabled = true;
                    btnGeneratePolicies.Enabled = true;
                    btnGenerateClaims.Enabled = true;
                    btnGeneratePayments.Enabled = true;
                    btnExportPolicies.Enabled = true;
                    btnExportClaims.Enabled = true;
                    btnExportPayments.Enabled = true;
                    txtPolicyholderID.Enabled = true;
                    break;
                case "agent":
                    tabControlReports.Enabled = true;
                    btnGeneratePolicies.Enabled = true;
                    btnGenerateClaims.Enabled = true;
                    btnGeneratePayments.Enabled = true;
                    btnExportPolicies.Enabled = true;
                    btnExportClaims.Enabled = true;
                    btnExportPayments.Enabled = true;
                    txtPolicyholderID.Enabled = true;
                    break;
                case "client":
                    tabControlReports.Enabled = true;
                    btnGeneratePolicies.Enabled = true;
                    btnGenerateClaims.Enabled = true;
                    btnGeneratePayments.Enabled = true;
                    btnExportPolicies.Enabled = false;
                    btnExportClaims.Enabled = false;
                    btnExportPayments.Enabled = false;
                    txtPolicyholderID.Enabled = false;
                    txtPolicyholderID.Text = currentUserId;
                    break;
                default:
                    tabControlReports.Enabled = false;
                    btnGeneratePolicies.Enabled = false;
                    btnGenerateClaims.Enabled = false;
                    btnGeneratePayments.Enabled = false;
                    btnExportPolicies.Enabled = false;
                    btnExportClaims.Enabled = false;
                    btnExportPayments.Enabled = false;
                    txtPolicyholderID.Enabled = false;
                    btnReturn.Enabled = true;
                    break;
            }
        }
        private void GeneratePoliciesReport()
        {
            if (!ValidateDateRange(dtpPoliciesStartDate.Value, dtpPoliciesEndDate.Value))
                return;

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "SELECT PolicyID, PolicyholderID, PolicyType, StartDate, EndDate, Premium, Status " +
                              "FROM Policy WHERE StartDate BETWEEN @startDate AND @endDate";
                if (!string.IsNullOrWhiteSpace(txtPolicyholderID.Text))
                    query += " AND PolicyholderID = @policyholderID";
                if (userRole.ToLower() == "client")
                    query += " AND PolicyholderID = @clientID";

                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@startDate", dtpPoliciesStartDate.Value);
                cmd.Parameters.AddWithValue("@endDate", dtpPoliciesEndDate.Value);
                if (!string.IsNullOrWhiteSpace(txtPolicyholderID.Text))
                    cmd.Parameters.AddWithValue("@policyholderID", txtPolicyholderID.Text);
                if (userRole.ToLower() == "client")
                    cmd.Parameters.AddWithValue("@clientID", currentUserId);

                try
                {
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    var dt = new DataTable();
                    adapter.Fill(dt);
                    dgvPoliciesReport.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error generating Policies report: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void GenerateClaimsReport()
        {
            if (!ValidateDateRange(dtpClaimsStartDate.Value, dtpClaimsEndDate.Value))
                return;

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "SELECT ClaimID, PolicyID, ClaimType, IncidentDate, Description, Amount, Status " +
                              "FROM Claim WHERE IncidentDate BETWEEN @startDate AND @endDate";
                if (!string.IsNullOrWhiteSpace(txtPolicyholderID.Text))
                    query += " AND PolicyID IN (SELECT PolicyID FROM Policy WHERE PolicyholderID = @policyholderID)";
                if (userRole.ToLower() == "client")
                    query += " AND PolicyID IN (SELECT PolicyID FROM Policy WHERE PolicyholderID = @clientID)";

                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@startDate", dtpClaimsStartDate.Value);
                cmd.Parameters.AddWithValue("@endDate", dtpClaimsEndDate.Value);
                if (!string.IsNullOrWhiteSpace(txtPolicyholderID.Text))
                    cmd.Parameters.AddWithValue("@policyholderID", txtPolicyholderID.Text);
                if (userRole.ToLower() == "client")
                    cmd.Parameters.AddWithValue("@clientID", currentUserId);

                try
                {
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    var dt = new DataTable();
                    adapter.Fill(dt);
                    dgvClaimsReport.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error generating Claims report: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void GeneratePaymentsReport()
        {
            if (!ValidateDateRange(dtpPaymentsStartDate.Value, dtpPaymentsEndDate.Value))
                return;

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "SELECT PaymentID, PolicyID, Amount, PaymentDate, PaymentMethod, Status " +
                              "FROM Payment WHERE PaymentDate BETWEEN @startDate AND @endDate";
                if (!string.IsNullOrWhiteSpace(txtPolicyholderID.Text))
                    query += " AND PolicyID IN (SELECT PolicyID FROM Policy WHERE PolicyholderID = @policyholderID)";
                if (userRole.ToLower() == "client")
                    query += " AND PolicyID IN (SELECT PolicyID FROM Policy WHERE PolicyholderID = @clientID)";
                
                if (userRole.ToLower() == "agent")//limiting data for agents
                    query = "SELECT PaymentID, PolicyID, Amount, PaymentDate, Status " +
                            "FROM Payment WHERE PaymentDate BETWEEN @startDate AND @endDate" +
                            (string.IsNullOrWhiteSpace(txtPolicyholderID.Text) ? "" : " AND PolicyID IN (SELECT PolicyID FROM Policy WHERE PolicyholderID = @policyholderID)");

                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@startDate", dtpPaymentsStartDate.Value);
                cmd.Parameters.AddWithValue("@endDate", dtpPaymentsEndDate.Value);
                if (!string.IsNullOrWhiteSpace(txtPolicyholderID.Text))
                    cmd.Parameters.AddWithValue("@policyholderID", txtPolicyholderID.Text);
                if (userRole.ToLower() == "client")
                    cmd.Parameters.AddWithValue("@clientID", currentUserId);

                try
                {
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    var dt = new DataTable();
                    adapter.Fill(dt);
                    dgvPaymentsReport.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error generating Payments report: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ExportToCSV(DataGridView dgv, string reportType)
        {
            if (dgv.Rows.Count == 0)
            {
                MessageBox.Show("No data to export!", "Export Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string filePath = Path.Combine(desktopPath, $"{reportType}_Report_{timestamp}.csv");

                StringBuilder csv = new StringBuilder();
                // Write headers
                var headers = dgv.Columns.Cast<DataGridViewColumn>().Select(c => $"\"{c.HeaderText}\"");
                csv.AppendLine(string.Join(",", headers));

                // Write rows
                foreach (DataGridViewRow row in dgv.Rows)
                {
                    var cells = row.Cells.Cast<DataGridViewCell>()
                        .Select(cell => $"\"{(cell.Value?.ToString() ?? "").Replace("\"", "\"\"")}\"");
                    csv.AppendLine(string.Join(",", cells));
                }

                File.WriteAllText(filePath, csv.ToString());
                MessageBox.Show($"Report exported to {filePath}", "Export Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error exporting to CSV: " + ex.Message, "Export Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnGeneratePolicies_Click(object sender, EventArgs e)
        {
            GeneratePoliciesReport();
        }

        private void btnExportPolicies_Click(object sender, EventArgs e)
        {
            ExportToCSV(dgvPoliciesReport, "Policies");
        }

        private void btnGenerateClaims_Click(object sender, EventArgs e)
        {
            GenerateClaimsReport();
        }

        private void btnExportClaims_Click(object sender, EventArgs e)
        {
            ExportToCSV(dgvPoliciesReport, "Claims");
        }

        private void btnGeneratePayments_Click(object sender, EventArgs e)
        {
            GeneratePaymentsReport();
        }

        private void btnExportPayments_Click(object sender, EventArgs e)
        {
            ExportToCSV(dgvPoliciesReport, "Payments");
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
