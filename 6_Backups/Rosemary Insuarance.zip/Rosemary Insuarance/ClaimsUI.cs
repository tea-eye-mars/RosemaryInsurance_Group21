﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rosemary_Insuarance
{
    public partial class ClaimsUI: Form
    {
        private string userRole;
        private string uploadedFilePath;
        private string currentUserId;

        public ClaimsUI(string role, string userId = null)
        {
            InitializeComponent();
            userRole = role;
            currentUserId = userId; // Passed from LoginUI or HomeUI
            LoadClaims();
            ConfigureAccess();
        }

        private void ConfigureAccess()
        {
            switch (userRole.ToLower())
            {
                case "admin":
                    btnFileClaim.Enabled = true;
                    btnUpdate.Enabled = true;
                    btnDelete.Enabled = true;
                    btnSearch.Enabled = true;
                    btnClear.Enabled = true;
                    cmbStatus.Enabled = true;
                    break;
                case "agent":
                    btnFileClaim.Enabled = true;
                    btnUpdate.Enabled = true;
                    btnDelete.Enabled = false;
                    btnSearch.Enabled = true;
                    btnClear.Enabled = true;
                    cmbStatus.Enabled = true;
                    break;
                case "client":
                    btnFileClaim.Enabled = true;
                    btnUpdate.Enabled = false;
                    btnDelete.Enabled = false;
                    btnSearch.Enabled = true;
                    btnClear.Enabled = true;
                    cmbStatus.Enabled = false;
                    break;
                default:
                    btnFileClaim.Enabled = false;
                    btnUpdate.Enabled = false;
                    btnDelete.Enabled = false;
                    btnSearch.Enabled = false;
                    btnClear.Enabled = false;
                    btnReturn.Enabled = true;
                    break;
            }
        }

        private void LoadClaims()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                try
                {
                    string query = "SELECT ClaimID, PolicyID, ClaimType, IncidentDate, Description, Amount, Status FROM Claim";
                    if (userRole.ToLower() == "client" && !string.IsNullOrEmpty(currentUserId))
                    {
                        query += " WHERE PolicyID IN (SELECT PolicyID FROM Policy WHERE PolicyholderID = @clientId)";
                    }
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    if (userRole.ToLower() == "client" && !string.IsNullOrEmpty(currentUserId))
                    {
                        cmd.Parameters.AddWithValue("@clientId", currentUserId);
                    }
                    var adapter = new MySqlDataAdapter(cmd);
                    var dt = new DataTable();
                    adapter.Fill(dt);
                    dgvClaims.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading claims: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ClearFields()
        {
            txtClaimID.Text = "";
            txtPolicyID.Text = "";
            cmbClaimType.SelectedIndex = -1;
            dtpIncidentDate.Value = DateTime.Now;
            txtDescription.Text = "";
            numAmount.Value = 0;
            cmbStatus.SelectedIndex = -1;
            uploadedFilePath = null;
        }

        private void btnFileClaim_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPolicyID.Text) || cmbClaimType.SelectedIndex == -1 ||
                string.IsNullOrWhiteSpace(txtDescription.Text) || numAmount.Value <= 0)
            {
                MessageBox.Show("Policy ID, Claim Type, Description, and Amount are required!",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "INSERT INTO Claim (PolicyID, ClaimType, IncidentDate, Description, Amount, Status, Documents) " +
                              "VALUES (@PolicyID, @ClaimType, @IncidentDate, @Description, @Amount, @Status, @Documents)";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@PolicyID", txtPolicyID.Text);
                cmd.Parameters.AddWithValue("@ClaimType", cmbClaimType.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@IncidentDate", dtpIncidentDate.Value);
                cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                cmd.Parameters.AddWithValue("@Amount", numAmount.Value);
                cmd.Parameters.AddWithValue("@Status", "Pending");
                cmd.Parameters.AddWithValue("@Documents", uploadedFilePath ?? "");

                try
                {
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    MessageBox.Show($"{rows} claim(s) filed.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadClaims();
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error filing claim: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtClaimID.Text))
            {
                MessageBox.Show("Select a claim to update!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "UPDATE Claim SET PolicyID = @PolicyID, ClaimType = @ClaimType, IncidentDate = @IncidentDate, " +
                              "Description = @Description, Amount = @Amount, Status = @Status, Documents = @Documents " +
                              "WHERE ClaimID = @ClaimID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@PolicyID", txtPolicyID.Text);
                cmd.Parameters.AddWithValue("@ClaimType", cmbClaimType.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@IncidentDate", dtpIncidentDate.Value);
                cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                cmd.Parameters.AddWithValue("@Amount", numAmount.Value);
                cmd.Parameters.AddWithValue("@Status", cmbStatus.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@Documents", uploadedFilePath ?? "");
                cmd.Parameters.AddWithValue("@ClaimID", txtClaimID.Text);

                try
                {
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    MessageBox.Show($"{rows} claim(s) updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadClaims();
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating claim: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtClaimID.Text))
            {
                MessageBox.Show("Select a claim to delete!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Are you sure you want to delete this claim?", "Confirm Delete",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string query = "DELETE FROM Claim WHERE ClaimID = @ClaimID";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ClaimID", txtClaimID.Text);

                    try
                    {
                        conn.Open();
                        int rows = cmd.ExecuteNonQuery();
                        MessageBox.Show($"{rows} claim(s) deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadClaims();
                        ClearFields();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting claim: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "SELECT ClaimID, PolicyID, ClaimType, IncidentDate, Description, Amount, Status FROM Claim " +
                              "WHERE ClaimID LIKE @search OR PolicyID LIKE @search";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@search", "%" + txtClaimID.Text + "%");

                try
                {
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    var dt = new DataTable();
                    adapter.Fill(dt);
                    dgvClaims.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error searching claims: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
