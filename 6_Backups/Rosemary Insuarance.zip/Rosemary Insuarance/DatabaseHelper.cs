﻿using MySql.Data.MySqlClient;
using System.Configuration;

namespace Rosemary_Insuarance
{
    public static class DatabaseHelper
    {
        private static string connectionString =
            ConfigurationManager.ConnectionStrings["RosemaryDB"].ConnectionString;

        public static MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }
    }
}
