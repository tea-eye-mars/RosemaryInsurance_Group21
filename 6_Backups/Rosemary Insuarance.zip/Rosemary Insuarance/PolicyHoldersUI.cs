﻿using MySql.Data.MySqlClient;
using Rosemary_Insuarance;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Rosemary_Insuarance
{
    public partial class PolicyHoldersUI : Form
    {
        private string userRole;

        public PolicyHoldersUI(string role)
        {
            InitializeComponent();
            LoadPolicyholders();
            userRole = role;
            ConfigureAccess();
        }
       
        private void ConfigureAccess()
        {
            switch (userRole.ToLower())
            {
                case "admin":
                    btnAdd.Enabled = true;
                    btnUpdate.Enabled = true;
                    btnDelete.Enabled = true;
                    btnSearch.Enabled = true;
                    btnClear.Enabled = true;
                    break;

                case "agent":
                    btnAdd.Enabled = true;
                    btnUpdate.Enabled = true;
                    btnDelete.Enabled = false;
                    btnSearch.Enabled = true;
                    btnClear.Enabled = true;
                    break;

                case "client":
                    btnAdd.Enabled = false;
                    btnUpdate.Enabled = false;
                    btnDelete.Enabled = false;
                    btnSearch.Enabled = true; // Allow search but it must only search the client's records...think about it
                    btnClear.Enabled = true;
                    //Maybe we should also only show the clients records on the grid...If I had energy I would
                    break;

                default:
                    btnAdd.Enabled = false;
                    btnUpdate.Enabled = false;
                    btnDelete.Enabled = false;
                    btnSearch.Enabled = false;
                    btnClear.Enabled = false;
                    btnReturn.Enabled = true;
                    break;
            }
        }

        private void LoadPolicyholders()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "SELECT * FROM Policyholder";
                var adapter = new MySqlDataAdapter(query, conn);
                var dt = new System.Data.DataTable();
                adapter.Fill(dt);
                dgvPolicyholders.DataSource = dt;
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)//the problem starts here
        {

            if (string.IsNullOrWhiteSpace(txtFullName.Text) || string.IsNullOrWhiteSpace(txtNationalID.Text))
            {
                MessageBox.Show("Full Name and National ID are required!");
                return;
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "INSERT INTO Policyholder (FullName, NationalID, Email, Phone, Address) " +
                               "VALUES (@FullName, @NationalID, @Email, @Phone, @Address)";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@FullName", txtFullName.Text);
                cmd.Parameters.AddWithValue("@NationalID", txtNationalID.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@Phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@Address", txtAddress.Text);

                try
                {
                    conn.Open();

                    int rows = cmd.ExecuteNonQuery();
                    MessageBox.Show($"{rows} row(s) inserted.");
                }
                catch(Exception f)
                {
                    MessageBox.Show("Error: " + f.Message);
                }
                finally
                {
                    conn.Close();
                }
        
                LoadPolicyholders();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "UPDATE Policyholder SET FullName=@FullName, Email=@Email, Phone=@Phone, Address=@Address " +
                               "WHERE NationalID=@NationalID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@FullName", txtFullName.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@Phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@NationalID", txtNationalID.Text);

                try
                {
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    MessageBox.Show($"{rows} row(s) updated successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn.Close();
                }

                LoadPolicyholders();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "DELETE FROM Policyholder WHERE NationalID=@NationalID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@NationalID", txtNationalID.Text);

                try
                {
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    MessageBox.Show($"{rows} row(s) deleted successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn.Close();
                }

                LoadPolicyholders();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "SELECT * FROM Policyholder WHERE FullName LIKE @search OR NationalID LIKE @search";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@search", "%" + txtFullName.Text + "%");

                try
                {
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    var dt = new DataTable();
                    adapter.Fill(dt);
                    dgvPolicyholders.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFullName.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtNationalID.Text = string.Empty;
            txtPhone.Text = string.Empty;
        }
    }
}

