# Rosemary Insurance Management System (Group 21) — Final Report Template

**Technology:** .NET 8, .NET MAUI (MVVM), SQLite (offline), SQL Server (central), ASP.NET Core Web API (sync)

## 1. Executive Summary
- Problem statement
- Objectives (from Policy Group 21 PDF)
- Scope & constraints
- Outcomes

## 2. Requirements Mapping
- 4.1 Policyholder Management — features implemented
- 4.2 Policy Management — features implemented
- 4.3 Claims Management — features implemented
- 4.4 Payments & Billing — features implemented
- 4.5 Reporting — summaries, exports
- 4.6 Authentication & Roles — Admin/Agent/Client

## 3. System Architecture
- MAUI client app
- Offline-first using SQLite
- Sync to SQL Server via Web API
- Diagrams (include ERD and component diagram)

## 4. Data Model
- Entities and relationships
- ERD (attach ERD.drawio export)
- Table design decisions

## 5. UI/UX
- Screens & navigation
- Role-based visibility
- Accessibility considerations

## 6. Implementation
- Project structure
- Key patterns (MVVM, dependency injection)
- Packages used (sqlite-net-pcl, CommunityToolkit.Mvvm)

## 7. Testing
- Unit tests (if any)
- Manual test scenarios
- UAT feedback

## 8. Security & Privacy
- Authentication, hashing
- Authorization by role
- Data backup & recovery

## 9. Deployment
- Windows & Android build steps
- Packaging
- Connection to central API

## 10. Timeline & Deliverables
- Phases and dates
- Submission artifacts

## 11. Conclusion & Future Work
- Lessons learned
- Improvements & next steps

---

### Appendices
- A. Screenshots
- B. API endpoints
- C. SQL Server schema
