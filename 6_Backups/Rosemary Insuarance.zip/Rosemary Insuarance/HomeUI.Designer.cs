﻿namespace Rosemary_Insuarance
{
    partial class HomeUI
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnPolicyholders;
        private System.Windows.Forms.Button btnPolicies;
        private System.Windows.Forms.Button btnClaims;
        private System.Windows.Forms.Button btnPayments;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel lblStatus;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnPolicyholders = new System.Windows.Forms.Button();
            this.btnPolicies = new System.Windows.Forms.Button();
            this.btnClaims = new System.Windows.Forms.Button();
            this.btnPayments = new System.Windows.Forms.Button();
            this.btnReports = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblWelcome.Location = new System.Drawing.Point(200, 30);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(400, 40);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.Text = "Welcome to Rosemary Insurance";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPolicyholders
            // 
            this.btnPolicyholders.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnPolicyholders.Location = new System.Drawing.Point(150, 120);
            this.btnPolicyholders.Name = "btnPolicyholders";
            this.btnPolicyholders.Size = new System.Drawing.Size(200, 50);
            this.btnPolicyholders.TabIndex = 1;
            this.btnPolicyholders.Text = "Policyholders";
            this.btnPolicyholders.UseVisualStyleBackColor = true;
            this.btnPolicyholders.Click += new System.EventHandler(this.btnPolicyholders_Click);
            // 
            // btnPolicies
            // 
            this.btnPolicies.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnPolicies.Location = new System.Drawing.Point(450, 120);
            this.btnPolicies.Name = "btnPolicies";
            this.btnPolicies.Size = new System.Drawing.Size(200, 50);
            this.btnPolicies.TabIndex = 2;
            this.btnPolicies.Text = "Policies";
            this.btnPolicies.UseVisualStyleBackColor = true;
            this.btnPolicies.Click += new System.EventHandler(this.btnPolicies_Click);
            // 
            // btnClaims
            // 
            this.btnClaims.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnClaims.Location = new System.Drawing.Point(150, 200);
            this.btnClaims.Name = "btnClaims";
            this.btnClaims.Size = new System.Drawing.Size(200, 50);
            this.btnClaims.TabIndex = 3;
            this.btnClaims.Text = "Claims";
            this.btnClaims.UseVisualStyleBackColor = true;
            this.btnClaims.Click += new System.EventHandler(this.btnClaims_Click);
            // 
            // btnPayments
            // 
            this.btnPayments.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnPayments.Location = new System.Drawing.Point(450, 200);
            this.btnPayments.Name = "btnPayments";
            this.btnPayments.Size = new System.Drawing.Size(200, 50);
            this.btnPayments.TabIndex = 4;
            this.btnPayments.Text = "Payments";
            this.btnPayments.UseVisualStyleBackColor = true;
            this.btnPayments.Click += new System.EventHandler(this.btnPayments_Click);
            // 
            // btnReports
            // 
            this.btnReports.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnReports.Location = new System.Drawing.Point(300, 280);
            this.btnReports.Name = "btnReports";
            this.btnReports.Size = new System.Drawing.Size(200, 50);
            this.btnReports.TabIndex = 5;
            this.btnReports.Text = "Reports";
            this.btnReports.UseVisualStyleBackColor = true;
            this.btnReports.Click += new System.EventHandler(this.btnReports_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnLogout.Location = new System.Drawing.Point(650, 350);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(100, 40);
            this.btnLogout.TabIndex = 6;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblStatus});
            this.statusStrip.Location = new System.Drawing.Point(0, 424);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(800, 26);
            this.statusStrip.TabIndex = 7;
            this.statusStrip.Text = "statusStrip1";
            // 
            // lblStatus
            // 
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(145, 20);
            this.lblStatus.Text = "Logged in as: Admin";
            // 
            // HomeUI
            // 
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.btnPolicyholders);
            this.Controls.Add(this.btnPolicies);
            this.Controls.Add(this.btnClaims);
            this.Controls.Add(this.btnPayments);
            this.Controls.Add(this.btnReports);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.statusStrip);
            this.Name = "HomeUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home - Rosemary Insurance";
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
    }
}
