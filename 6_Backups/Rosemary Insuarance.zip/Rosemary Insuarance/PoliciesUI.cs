﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rosemary_Insuarance
{
    public partial class PoliciesUI: Form
    {
        private string userRole;
        private string currentUserId;

        public PoliciesUI(string role, string username)
        {
            InitializeComponent();
            userRole = role;
            currentUserId = GetUserNationalID(username); // Get NationalID for client filtering
            LoadPolicies();
            ConfigureAccess();
        }
        private string GetUserNationalID(string username)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                try
                {
                    conn.Open();
                    string query = "SELECT NationalID FROM Policyholder WHERE Username = @username";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@username", username);
                    object result = cmd.ExecuteScalar();
                    return result?.ToString() ?? "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving user ID: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return "";
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void ConfigureAccess()
        {
            switch (userRole.ToLower())
            {
                case "admin":
                    btnAdd.Enabled = true;
                    btnUpdate.Enabled = true;
                    btnCancel.Enabled = true;
                    btnSearch.Enabled = true;
                    btnClear.Enabled = true;
                    cmbStatus.Enabled = true;
                    break;
                case "agent":
                    btnAdd.Enabled = true;
                    btnUpdate.Enabled = true;
                    btnCancel.Enabled = false;
                    btnSearch.Enabled = true;
                    btnClear.Enabled = true;
                    cmbStatus.Enabled = true;
                    break;
                case "client":
                    btnAdd.Enabled = false;
                    btnUpdate.Enabled = false;
                    btnCancel.Enabled = false;
                    btnSearch.Enabled = true;
                    btnClear.Enabled = true;
                    cmbStatus.Enabled = false;
                    txtPolicyholderID.Enabled = false; 
                    txtPolicyholderID.Text = currentUserId; 
                    break;
                default:
                    btnAdd.Enabled = false;
                    btnUpdate.Enabled = false;
                    btnCancel.Enabled = false;
                    btnSearch.Enabled = false;
                    btnClear.Enabled = false;
                    btnReturn.Enabled = true;
                    break;
            }
        }

        private void LoadPolicies()
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "SELECT PolicyID, PolicyholderID, PolicyType, StartDate, EndDate, Premium, Status FROM Policy";
                if (userRole.ToLower() == "client")
                {
                    query += " WHERE PolicyholderID = @policyholderId";
                }
                MySqlCommand cmd = new MySqlCommand(query, conn);
                if (userRole.ToLower() == "client")
                {
                    cmd.Parameters.AddWithValue("@policyholderId", currentUserId);
                }
                try
                {
                    var adapter = new MySqlDataAdapter(cmd);
                    var dt = new DataTable();
                    adapter.Fill(dt);
                    dgvPolicies.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading policies: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void ClearFields()
        {
            txtPolicyID.Text = "";
            txtPolicyholderID.Text = userRole.ToLower() == "client" ? currentUserId : "";
            cmbPolicyType.SelectedIndex = -1;
            dtpStartDate.Value = DateTime.Now;
            dtpEndDate.Value = DateTime.Now.AddYears(1); // Default to 1-year policy
            numPremium.Value = 0;
            cmbStatus.SelectedIndex = -1;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPolicyID.Text) ||
                string.IsNullOrWhiteSpace(txtPolicyholderID.Text) ||
                cmbPolicyType.SelectedIndex == -1 ||
                numPremium.Value <= 0)
            {
                MessageBox.Show("Policy ID, Policyholder ID, Policy Type, and Premium are required!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "INSERT INTO Policy (PolicyID, PolicyholderID, PolicyType, StartDate, EndDate, Premium, Status) " +
                              "VALUES (@PolicyID, @PolicyholderID, @PolicyType, @StartDate, @EndDate, @Premium, @Status)";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@PolicyID", txtPolicyID.Text);
                cmd.Parameters.AddWithValue("@PolicyholderID", txtPolicyholderID.Text);
                cmd.Parameters.AddWithValue("@PolicyType", cmbPolicyType.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@StartDate", dtpStartDate.Value);
                cmd.Parameters.AddWithValue("@EndDate", dtpEndDate.Value);
                cmd.Parameters.AddWithValue("@Premium", numPremium.Value);
                cmd.Parameters.AddWithValue("@Status", cmbStatus.SelectedItem?.ToString() ?? "Pending");

                try
                {
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    MessageBox.Show($"{rows} policy(ies) added.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding policy: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn.Close();
                }

                LoadPolicies();
                ClearFields();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPolicyID.Text))
            {
                MessageBox.Show("Select a policy to update!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "UPDATE Policy SET PolicyholderID = @PolicyholderID, PolicyType = @PolicyType, " +
                              "StartDate = @StartDate, EndDate = @EndDate, Premium = @Premium, Status = @Status " +
                              "WHERE PolicyID = @PolicyID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@PolicyID", txtPolicyID.Text);
                cmd.Parameters.AddWithValue("@PolicyholderID", txtPolicyholderID.Text);
                cmd.Parameters.AddWithValue("@PolicyType", cmbPolicyType.SelectedItem.ToString());
                cmd.Parameters.AddWithValue("@StartDate", dtpStartDate.Value);
                cmd.Parameters.AddWithValue("@EndDate", dtpEndDate.Value);
                cmd.Parameters.AddWithValue("@Premium", numPremium.Value);
                cmd.Parameters.AddWithValue("@Status", cmbStatus.SelectedItem.ToString());

                try
                {
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    MessageBox.Show($"{rows} policy(ies) updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating policy: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn.Close();
                }

                LoadPolicies();
                ClearFields();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPolicyID.Text))
            {
                MessageBox.Show("Select a policy to cancel!", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Are you sure you want to cancel this policy?", "Confirm Cancel", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    string query = "UPDATE Policy SET Status = 'Cancelled' WHERE PolicyID = @PolicyID";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@PolicyID", txtPolicyID.Text);

                    try
                    {
                        conn.Open();
                        int rows = cmd.ExecuteNonQuery();
                        MessageBox.Show($"{rows} policy(ies) cancelled.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error cancelling policy: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conn.Close();
                    }

                    LoadPolicies();
                    ClearFields();
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                string query = "SELECT PolicyID, PolicyholderID, PolicyType, StartDate, EndDate, Premium, Status " +
                              "FROM Policy WHERE PolicyID LIKE @search OR PolicyholderID LIKE @search";
                if (userRole.ToLower() == "client")
                {
                    query += " AND PolicyholderID = @policyholderId";
                }
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@search", "%" + txtPolicyID.Text + "%");
                if (userRole.ToLower() == "client")
                {
                    cmd.Parameters.AddWithValue("@policyholderId", currentUserId);
                }

                try
                {
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    var dt = new DataTable();
                    adapter.Fill(dt);
                    dgvPolicies.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error searching policies: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvPolicies_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
