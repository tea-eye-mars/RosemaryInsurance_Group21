﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rosemary_Insuarance
{
    public partial class HomeUI: Form
    {

        private string userRole;
        private string username;

        public HomeUI(string role, string username)
        {
            InitializeComponent();
            userRole = role;
            ConfigureAccess(); //Set up button visibility based on role
            this.username = username;
        }

        private void ConfigureAccess()
        {
            // Update status strip to show role
            lblStatus.Text = $"Logged in as: {userRole}";

            // Role-based button access
            switch (userRole.ToLower())
            {
                case "admin":
                    // Full access: all buttons enabled
                    btnPolicyholders.Enabled = true;
                    btnPolicies.Enabled = true;
                    btnClaims.Enabled = true;
                    btnPayments.Enabled = true;
                    btnReports.Enabled = true;
                    break;

                case "agent":
                    // Access to most, no reports
                    btnPolicyholders.Enabled = true;
                    btnPolicies.Enabled = true;
                    btnClaims.Enabled = true;
                    btnPayments.Enabled = true;
                    btnReports.Enabled = false; // No reports for agents
                    break;

                case "client":
                    // Limited access: claims, payments, view-only policies
                    btnPolicyholders.Enabled = false; // No policyholder management
                    btnPolicies.Enabled = true; // View own policies
                    btnClaims.Enabled = true; // File/view own claims
                    btnPayments.Enabled = true; // View own payments
                    btnReports.Enabled = false; // No reports
                    break;

                default:
                    MessageBox.Show("Invalid role detected!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    btnPolicyholders.Enabled = false;
                    btnPolicies.Enabled = false;
                    btnClaims.Enabled = false;
                    btnPayments.Enabled = false;
                    btnReports.Enabled = false;
                    btnLogout.Enabled = true; // Allow logout even on error
                    break;
            }
        }
        private void btnPolicyholders_Click(object sender, EventArgs e)
        {
            PolicyHoldersUI policyholdersUI = new PolicyHoldersUI(userRole);
            policyholdersUI.ShowDialog();
        }

        private void btnClaims_Click(object sender, EventArgs e)
        {
            ClaimsUI claimsUI = new ClaimsUI(userRole, username);
            claimsUI.ShowDialog();
        }

        private void btnPolicies_Click(object sender, EventArgs e)
        {
            PoliciesUI policiesUI = new PoliciesUI(userRole, username);
            policiesUI.ShowDialog();
        }

        private void btnPayments_Click(object sender, EventArgs e)
        {
            PaymentsUI paymentsUI = new PaymentsUI(userRole, username);
            paymentsUI.ShowDialog();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            ReportsUI reportsUI = new ReportsUI(userRole, username);
            reportsUI.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginUI login = new LoginUI();
            login.Show();
        }
    }
}
